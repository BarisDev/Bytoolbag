import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  num num1, num2, result;

  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();

  plus() {
    setState(() {
      num1 = num.parse(t1.text);
      num2 = num.parse(t2.text);
      result = num1 + num2;
    });
  }

  minus() {
    setState(() {
      num1 = num.parse(t1.text);
      num2 = num.parse(t2.text);
      result = num1 - num2;
    });
  }

  multiply() {
    setState(() {
      num1 = num.parse(t1.text);
      num2 = num.parse(t2.text);
      result = num1 * num2;
    });
  }

  divide() {
    setState(() {
      num1 = num.parse(t1.text);
      num2 = num.parse(t2.text);
      result = num1 / num2;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).calculatortitle),
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            ListTile(
              title: Text('$result'),
            ),
            TextField(
              controller: t1,
            ),
            TextField(
              controller: t2,
            ),
            RaisedButton(
              onPressed: plus,
              child: Text(AppLocalizations.of(context).plus),
            ),
            RaisedButton(
              onPressed: minus,
              child: Text(AppLocalizations.of(context).minus),
            ),
            RaisedButton(
              onPressed: multiply,
              child: Text(AppLocalizations.of(context).multiply),
            ),
            RaisedButton(
              onPressed: divide,
              child: Text(AppLocalizations.of(context).dividedby),
            ),
          ],
        ),
      ),
    );
  }
}
