import 'package:flutter/material.dart';
import 'package:flutter_toolbag/calculator.dart';
import 'settings.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ByApp());
}

class ByApp extends StatefulWidget {
  static void setLocale(BuildContext context, Locale newLocale) async {
    _ByAppState state = context.findAncestorStateOfType<_ByAppState>();
    state.changeLanguage(newLocale);
  }

  static void setTheme(BuildContext context, SettingsData data) async {
    _ByAppState state = context.findAncestorStateOfType<_ByAppState>();
    state.changeTheme(data);
  }

  static void updateFirebase(BuildContext context, Locale local) async {
    _ByAppState state = context.findAncestorStateOfType<_ByAppState>();
    state.updateFirebase(local);
  }

  @override
  _ByAppState createState() => _ByAppState();
}

//Locale local = Locale('en', 'US');
//LOCALE NULL OLDUĞUNDA DEFAULT OLARAK CİHAZIN DİLİNİ KULLANIR kaynak: docs
CollectionReference app = FirebaseFirestore.instance.collection('app');
Locale _locale;

class _ByAppState extends State<ByApp> {
  changeLanguage(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  Color appBarColor = Colors.blue,
      textColor = Colors.white,
      backgroundColor = Colors.white,
      buttonColor = Colors.grey[800],
      buttonTextColor = Colors.white;

  changeTheme(SettingsData data) {
    setState(() {
      appBarColor = data.appBarColor;
      textColor = data.buttonTextColor;
      backgroundColor = data.backgroundColor;
      buttonColor = data.buttonColor;
      buttonTextColor = data.buttonTextColor;
    });
  }

//Firebase update

  updateFirebase(Locale locale) {
    setState(() {
      app
          .doc('pref')
          .update(
              {'country': locale.countryCode, 'language': locale.languageCode})
          .then((value) => print("firebase locale updated"))
          .catchError((error) => print("Failed to update locale: $error"));
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "byToolbag",
      theme: new ThemeData(
        primaryColor: appBarColor,
        accentColor: buttonTextColor,
        scaffoldBackgroundColor: backgroundColor,
        textTheme: TextTheme(
          bodyText1: TextStyle(color: textColor),
          subtitle1: TextStyle(color: buttonColor), //textfield input color
        ),
        buttonTheme: ButtonThemeData(
          buttonColor: buttonColor,
          textTheme: ButtonTextTheme.accent,
        ),
      ),
      initialRoute: "/",
      routes: {
        "/": (context) => MainScreen(),
        "/SettingsRoute": (context) => SettingsScreen(),
        "/CalculatorRoute": (context) => CalculatorScreen(),
      },
      supportedLocales: [
        Locale('en', 'US'),
        Locale('tr', 'TR'),
      ],
      localizationsDelegates: [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      locale: _locale,
    );
  }
}

class MainScreen extends StatefulWidget {
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  //ByApp.changeTheme() öncesiydi
  //SettingsData data;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).maintitle),
      ),
      body: Center(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          RaisedButton(
              child: Text(
                AppLocalizations.of(context).calculatorbutton,
              ),
              padding: EdgeInsets.all(10.0),
              onPressed: () {
                Navigator.pushNamed(context, "/CalculatorRoute");
              }),
          RaisedButton(
              child: Text(
                AppLocalizations.of(context).settingsbutton,
              ),
              padding: EdgeInsets.all(10.0),
              onPressed: () {
                Navigator.pushNamed(context, "/SettingsRoute");
              }

              /*  Settings.dart dosyasında navigator.pop ile data objesini gönderirken bu method kullanılırdı. ByApp.changeTheme() methodu tanımlandıktan sonra bu kısım iptal 
              () async {
                var result =
                    await Navigator.pushNamed(context, "/SettingsRoute");
                setState(() {
                  data = result;
                })
                */
              )
        ],
      )),
    );
  }
}
