import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'main.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static bool _isSwitched = false;
  Icon _icon = new Icon(Icons.lightbulb_outlined, color: Colors.black);
  static Color _appBarColor = Colors.blue;
  static Color _backgroundColor = Colors.white;
  static Color _buttonColor = Colors.grey[800];
  static Color _buttonTextColor = Colors.white;

  @override
  Widget build(BuildContext context) {
    String dropdownValue =
        Localizations.localeOf(context).languageCode.toString();
    Locale local;
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).settingstitle),
      ),
      body: Center(
        child: ListView(
          children: <Widget>[
            SwitchListTile(
              title: Text(
                AppLocalizations.of(context).darkmode,
                style: TextStyle(color: _buttonTextColor),
              ),
              value: _isSwitched,
              secondary: _icon,
              tileColor: _buttonColor,
              inactiveThumbColor: _buttonTextColor,
              activeColor: _buttonTextColor,
              onChanged: (bool value) {
                setState(() {
                  _isSwitched = value;
                  if (_isSwitched == false) {
                    _icon = Icon(Icons.lightbulb_outlined);
                    _appBarColor = Colors.blue;
                    _backgroundColor = Colors.white;
                    _buttonColor = Colors.grey[800];
                    _buttonTextColor = Colors.white;

                    SettingsData data = new SettingsData(
                        appBarColor: _appBarColor,
                        backgroundColor: _backgroundColor,
                        buttonColor: _buttonColor,
                        buttonTextColor: _buttonTextColor);
                    ByApp.setTheme(context, data);
                  } else {
                    _icon = Icon(Icons.lightbulb_outline, color: Colors.black);

                    _appBarColor = Colors.black;
                    _backgroundColor = Colors.grey[850];
                    _buttonColor = Colors.white;
                    _buttonTextColor = Colors.black;

                    SettingsData data = new SettingsData(
                        appBarColor: _appBarColor,
                        backgroundColor: _backgroundColor,
                        buttonColor: _buttonColor,
                        buttonTextColor: _buttonTextColor);
                    ByApp.setTheme(context, data);
                  }
                });
              },
            ),
            Container(
              //padding: EdgeInsets.fromLTRB(10, 10, 30, 30),
              //margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
              color: _buttonColor,
              child: Center(
                  child: DropdownButton<String>(
                value: dropdownValue,
                isExpanded: true,
                dropdownColor: _buttonColor,
                iconSize: 30,
                iconEnabledColor: _buttonTextColor, //ok işareti
                style: TextStyle(color: _buttonTextColor),

                onChanged: (String newValue) {
                  setState(() {
                    dropdownValue = newValue;
                    switch (newValue) {
                      case 'tr':
                        {
                          local = Locale('tr', 'TR');
                          ByApp.setLocale(context, local);
                          ByApp.updateFirebase(context, local);
                        }
                        break;
                      case 'en':
                        {
                          local = Locale('en', 'US');
                          ByApp.setLocale(context, local);
                          ByApp.updateFirebase(context, local);
                        }
                        break;
                    }
                  });
                },
                items: <String>['tr', 'en']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              )),
            ),
          ],
        ),
      ),
    );
  }
}

class SettingsData {
  Color appBarColor, backgroundColor, buttonColor, buttonTextColor;

  SettingsData({
    this.appBarColor,
    this.backgroundColor,
    this.buttonColor,
    this.buttonTextColor,
  });
}
