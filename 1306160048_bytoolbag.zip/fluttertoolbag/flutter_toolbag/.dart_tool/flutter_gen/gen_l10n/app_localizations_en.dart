
// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: unnecessary_brace_in_string_interps

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get calculatorbutton => 'Calculator';

  @override
  String get calculatortitle => 'bytoolbag - Calculator';

  @override
  String get plus => 'plus';

  @override
  String get minus => 'minus';

  @override
  String get multiply => 'multiply';

  @override
  String get dividedby => 'divided by';

  @override
  String get settingsbutton => 'Settings';

  @override
  String get darkmode => 'Dark Mode';

  @override
  String get maintitle => 'byToolbag - Tools for Everyone';

  @override
  String get settingstitle => 'byToolbag - Settings';
}
