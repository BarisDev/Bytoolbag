
// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: unnecessary_brace_in_string_interps

/// The translations for Turkish (`tr`).
class AppLocalizationsTr extends AppLocalizations {
  AppLocalizationsTr([String locale = 'tr']) : super(locale);

  @override
  String get calculatorbutton => 'Hesap Makinesi';

  @override
  String get calculatortitle => 'bytoolbag - Hesap Makinesi';

  @override
  String get plus => 'topla';

  @override
  String get minus => 'çıkar';

  @override
  String get multiply => 'çarp';

  @override
  String get dividedby => 'böl';

  @override
  String get settingsbutton => 'Ayarlar';

  @override
  String get darkmode => 'Gece Modu';

  @override
  String get maintitle => 'byToolbag - Herkes için Araclar';

  @override
  String get settingstitle => 'byToolbag - Ayarlar';
}
